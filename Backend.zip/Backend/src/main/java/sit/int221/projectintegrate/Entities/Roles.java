package sit.int221.projectintegrate.Entities;

public enum Roles {
    admin,
    lecturer,
    student
}
