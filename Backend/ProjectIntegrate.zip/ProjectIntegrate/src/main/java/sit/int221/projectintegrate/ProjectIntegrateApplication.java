package sit.int221.projectintegrate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectIntegrateApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjectIntegrateApplication.class, args);
    }

}
