package sit.int221.projectintegrate.DTO;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.hibernate.validator.constraints.Length;
import sit.int221.projectintegrate.Entities.Events;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.Set;

@Data
@Getter
@Setter
public class SimpleUserDTO {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull
    @Length(max = 100,message = "Username up to 100 characters")
    private String username;

    @NotNull(message = "Email should not be null or empty.")
    @Email(message = "Email should be a valid email format.")
    @Length(max = 50,message = "Email up to 50 characters")
    private String email;

    @NotNull
    private String roles;

    private LocalDateTime createdOn;

    private LocalDateTime updatedOn;

}
