package sit.int221.projectintegrate.Entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "userId", nullable = false)
    private Integer id;

    @NotNull
    @Length(max = 100,message = "Username up to 100 characters")
    @Column(name = "username", nullable = false, length = 100)
    private String username;

    @NotNull(message = "Email should not be null or empty.")
    @Email(message = "Email should be a valid email format.")
    @Column(name = "email", nullable = false, length = 50)
    private String email;

    @Lob
    @Column(name = "roles", nullable = false)
    private String roles;

    @Column(name = "createdOn", nullable = false , insertable = false , updatable = false)
    private LocalDateTime createdOn;

    @Column(name = "updatedOn", nullable = false , insertable = false , updatable = false)
    private LocalDateTime updatedOn;


}